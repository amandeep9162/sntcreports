<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DailyReport;
use App\Models\User;
use Bitfumes\Multiauth\Model\Admin;
use Auth;
use Session;


class ReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $users = Admin::all();
        if(auth()->guard('admin')->user()->id != 1){
            $dailyReports = DailyReport::with('user')->where('status',1)->where('user_id',auth()->guard('admin')->user()->id)->orderBy('id','DESC')->get();
        }else{
            $dailyReports = DailyReport::with('user')->where('status',1)->orderBy('id','DESC')->get();
        }
        
        return view('multiauth::report.list',compact('users','dailyReports'));
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function reportFilter(Request $request)
    {
        $users = Admin::all();
        $data = DailyReport::with('user')->where('status',1);
        if($request->date){
            $data->where('date',$request->date);
        }elseif($request->inTime){
            $data->where('in_time',$request->inTime);
        }elseif($request->outTime){
            $data->where('out_time',$request->outTime);
        }elseif($request->has('name')){
            if($request->name[0] != 'all'){
        // dd($request->all());
                $data->whereIn('user_id',$request->name);

            }
        }
        $dailyReports = $data->get();
        return view('multiauth::report.list',compact('users','dailyReports'));
    }
     public function reportFilterTasks($id)
    {
        $users = Admin::all();
        $data = DailyReport::with('user')->where('status',1);
            if($id != 'all'){
        // dd($request->all());
                $data->where('id',$id);

            }
        
        $dailyReports = $data->get();
        return response()->json(['dailyReports'=>$dailyReports]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $dailyReports = DailyReport::where('date',date('Y-m-d'))->where('user_id',auth()->guard('admin')->user()->id)->first();
        if($dailyReports){
            if($dailyReports['status'] == 1){
                Session::flash('success','Today Report submitted');
                return redirect('/admin/home');
            }
        }
        return view('multiauth::report.add',compact('dailyReports'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $this->validate($request, [
        'in_time' => 'required|max:255',
        'out_time' => 'required|max:255',
        'report*' => 'required',
        ]);
        $dailyReports = DailyReport::where('date',date('Y-m-d'))->where('user_id',auth()->guard('admin')->user()->id)->first();
        if($request->name == 'submit'){
            $status = 1;
        }else{
            $status = 0;
        }
        
        if($dailyReports){
            DailyReport::where('date',date('Y-m-d'))->where('user_id',auth()->guard('admin')->user()->id)->update(['out_time' =>$request->out_time,'report' =>json_encode($request->report),'status' =>$status,]);
        }else{

            DailyReport::create([
                                'user_id' =>auth()->guard('admin')->user()->id,
                                'date' =>date('Y-m-d'),
                                'in_time' =>$request->in_time,
                                'out_time' =>$request->out_time,
                                'report' =>json_encode($request->report),
                                'status' =>$status,
                 ]);
        }
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $id = base64_decode($id);
        $dailyReports = DailyReport::with('user')->where('status',1)->where('user_id',$id)->get();
        return view('multiauth::report.filterdlist',compact('dailyReports'));
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       
        DailyReport::where('date',date('Y-m-d'))->where('user_id',auth()->guard('admin')->user()->id)->update(['status' =>1]);
        Session::flash('success','Report submitted');
        return redirect('/admin/home');

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
