<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DailyReport extends Model
{
    use HasFactory;
    public $table = "dailyreports";
    protected $fillable = ['user_id','date','in_time','out_time','report'];


    public function user(){

    	return $this->belongsTo('Bitfumes\Multiauth\Model\Admin','user_id','id');
    }
}
