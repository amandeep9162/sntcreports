@extends('layouts.app')
@section('content')
     <div class="content-page">
     <div class="container-fluid ">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header ">
                        <div class="header-title">
                            <h4 class="card-title">Genrate qr code</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="{{route('genrate.qrcode')}}" method="get" data-toggle="validator">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Unit Name *</label>
                                        <select name="unit_name" class="selectpicker form-control" data-style="py-0">
                                            @foreach($units as $unit)
                                            <option value="{{$unit['id']}}">{{$unit['name']}}</option>
                                            @endforeach
                                            
                                        </select>
                                    </div> 
                                </div>
                                <div class="col-md-6"> 
                                    <div class="form-group">
                                        <label>Farm  *</label>
                                        <select name="farm_name" class="selectpicker form-control" data-style="py-0">
                                            @foreach($farms as $farm)
                                            <option value="{{$farm['id']}}">{{$farm['name']}}</option>
                                            @endforeach
                                            
                                        </select>
                                    </div>
                                </div>   
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Bach no. *</label>
                                        <input type="text" class="form-control" placeholder="Enter Code" data-errors="Please Enter Code." name="batch_no" value="{{$batch}}" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Used By (days?)*</label>
                                        <input type="number" class="form-control" placeholder="Enter Code" data-errors="Please Enter Code." name="used_by"  required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div> 
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Dispatch Date *</label>
                                        <input type="date" class="form-control" placeholder="Enter Code" data-errors="Please Enter Code." name="dispatch_date" value="" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Received Date*</label>
                                        <input type="date" class="form-control" placeholder="Enter Code" data-errors="Please Enter Code." name="received_date"  required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Pack Date*</label>
                                        <input type="date" class="form-control" placeholder="Enter Code" data-errors="Please Enter Code." name="pack_date"  required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div> 
                                
                                
                            </div>                            
                            <button type="submit" class="btn btn-primary mr-2">Genrate</button>
                            <!-- <button type="reset" class="btn btn-danger">Reset</button> -->
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
      </div>
    </div>
    @endsection
  