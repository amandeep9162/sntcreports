<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>Employee Management</title>
      
      <!-- Favicon -->
      <link rel="shortcut icon" href="<?php echo e(asset('/favicon.ico')); ?>" />
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/backend-plugin.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/backende209.css?v=1.0.0')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fortawesome/fontawesome-free/css/all.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/remixicon/fonts/remixicon.css')); ?>">  
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet" />
<link href="https://cdn.datatables.net/buttons/1.6.1/css/buttons.dataTables.min.css" rel="stylesheet" />
<style>
      .popOver{
        background: #5eb47c;
    z-index: 999999;
    color: #ffffff;
    position: absolute;
    right: 0;
    top: 10;
    padding: 15px;
      }
    </style>
    </head>
  <body class="  ">
    <!-- loader Start -->
    <div id="loading">
          <div id="loading-center">
          </div>
    </div>
    <?php if(Session::has('success')): ?>
        <div class="btn btn-success popOver">
            <strong><?php echo Session::get('success'); ?></strong> 
        </div>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <div class="btn btn-danger popOver">
            <strong><?php echo Session::get('error'); ?></strong> 
        </div>
    <?php endif; ?>
    <!-- loader END -->
    <!-- Wrapper Start -->
    <div class="wrapper">
      
      <div class="iq-sidebar  sidebar-default ">
          <div class="iq-sidebar-logo d-flex align-items-center justify-content-between">
              <a href="<?php echo e(route('home')); ?>" class="header-logo">
                  <!-- <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-fluid rounded-normal light-logo" alt="logo"> --><h5 class="logo-title light-logo ml-3">Employee Management </h5>
              </a>
              <div class="iq-menu-bt-sidebar ml-0">
                  <i class="fa fa-list" style="color: #9b9fb2;font-size: 30px;"></i>
              </div>
          </div>
          <div class="data-scrollbar" data-scroll="1">
              <nav class="iq-sidebar-menu">
                  <ul id="iq-sidebar-toggle" class="iq-menu">
                      <li class="active">
                          <a href="<?php echo e(route('admin.home')); ?>" class="svg-icon">      
                        <i class="fa fa-home"></i>
                              <span class="ml-4">Dashboards</span>
                          </a>
                      </li>
                      <?php if (\Illuminate\Support\Facades\Blade::check('admin', 'super')): ?>
                      <li class=" ">
                          <a href="#report" class="collapsed" data-toggle="collapse" aria-expanded="false">
                            <i class="fa fa-check"></i>
                            <!-- <i class="fa-solid fa-clipboard-list-check"></i> -->
                              <span class="ml-4">Report</span>
                              <svg class="svg-icon iq-arrow-right arrow-active" width="20" height="20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <polyline points="10 15 15 20 20 15"></polyline><path d="M4 4h7a4 4 0 0 1 4 4v12"></path>
                              </svg>
                              
                          </a>
                          <ul id="report" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                              <li class="">
                                  
                                <a class="dropdown-item" href="<?php echo e(route('report.index')); ?>">List</a>
                                    
                              </li>
                              
                          </ul>
                      </li>
                      <?php else: ?>
                      <li class=" ">
                          <a href="#ereport" class="collapsed" data-toggle="collapse" aria-expanded="false">
                            <i class="fa fa-plus"></i>
                            <!-- <i class="fa-solid fa-clipboard-list-check"></i> -->
                              <span class="ml-4">Enter Report</span>
                              <svg class="svg-icon iq-arrow-right arrow-active" width="20" height="20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <polyline points="10 15 15 20 20 15"></polyline><path d="M4 4h7a4 4 0 0 1 4 4v12"></path>
                              </svg>
                              
                          </a>
                          <ul id="ereport" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                              <li class="">
                                  
                                <a class="dropdown-item" href="<?php echo e(route('report.create')); ?>">Add</a>
                                    
                              </li>
                              
                          </ul>
                      </li>
                      <?php endif; ?>

                      
                      <?php if (\Illuminate\Support\Facades\Blade::check('admin', 'super')): ?>
                      <li class=" ">
                          <a href="#product" class="collapsed" data-toggle="collapse" aria-expanded="false">
                            <i class="fa fa-users"></i>
                              <span class="ml-4">Users</span>
                              <svg class="svg-icon iq-arrow-right arrow-active" width="20" height="20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <polyline points="10 15 15 20 20 15"></polyline><path d="M4 4h7a4 4 0 0 1 4 4v12"></path>
                              </svg>
                              
                          </a>
                          <ul id="product" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                              <li class="">
                                  <?php if (\Illuminate\Support\Facades\Blade::check('admin', 'super')): ?>
                                <a class="dropdown-item" href="<?php echo e(route('admin.show')); ?>">Users</a>
                                    <a class="dropdown-item" href="<?php echo e(route('admin.show')); ?>">Add User</a>
                                    <?php endif; ?>
                              </li>
                              
                          </ul>
                      </li>

                      <li class=" ">
                          <a href="#category" class="collapsed" data-toggle="collapse" aria-expanded="false">
                            <i class="fa fa-id-card"></i>
                              <span class="ml-4">Roles</span>
                              <svg class="svg-icon iq-arrow-right arrow-active" width="20" height="20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <polyline points="10 15 15 20 20 15"></polyline><path d="M4 4h7a4 4 0 0 1 4 4v12"></path>
                              </svg>
                             
                          </a>
                          <ul id="category" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                 
                                  <li class="">
                                <?php if (\Illuminate\Support\Facades\Blade::check('admin', 'super')): ?>
                                
                                <?php if (\Illuminate\Support\Facades\Blade::check('permitToParent', 'Role')): ?>
                                <a class="dropdown-item" href="<?php echo e(route('admin.roles')); ?>">Roles</a>
                                <?php endif; ?>
                                <?php endif; ?>
                                  </li>
                          </ul>
                      </li>
                      <?php endif; ?>
                      <li class=" ">
                          <a href="#cp" class="collapsed" data-toggle="collapse" aria-expanded="false">
                            <i class="fa fa-key"></i>
                              <span class="ml-4">Change Password</span>
                              <svg class="svg-icon iq-arrow-right arrow-active" width="20" height="20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <polyline points="10 15 15 20 20 15"></polyline><path d="M4 4h7a4 4 0 0 1 4 4v12"></path>
                              </svg>
                             
                          </a>
                          <ul id="cp" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                 
                                   <li class="">
                                  <a class="dropdown-item" href="<?php echo e(route('admin.password.change')); ?>">Change Password</a>
                                  </li>
                          </ul>
                      </li>
                     
                  </ul>
              </nav>
             
              <div class="p-3"></div>
          </div>
          </div>      <div class="iq-top-navbar">
          <div class="iq-navbar-custom">
              <nav class="navbar navbar-expand-lg navbar-light p-0">
                  <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                      <i class="ri-menu-line wrapper-menu"></i>
                      <a href="javascript:;" class="header-logo">
                          <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-fluid rounded-normal" alt="logo">
                          <h5 class="logo-title ml-3">Employee Management</h5>
      
                      </a>
                  </div>
                  <div class="iq-search-bar device-search">
                      <!-- <form action="#" class="searchbox">
                          <a class="search-link" href="#"><i class="ri-search-line"></i></a>
                          <input type="text" class="text search-input" placeholder="Search here...">
                      </form> -->
                  </div>
                  <div class="d-flex align-items-center">
                      <button class="navbar-toggler" type="button" data-toggle="collapse"
                          data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                          aria-label="Toggle navigation">
                          <i class="ri-menu-3-line"></i>
                      </button>
                      <div class="collapse navbar-collapse" id="navbarSupportedContent">
                          <ul class="navbar-nav ml-auto navbar-list align-items-center">
                             
                              <li>
                                 <!--  <a href="<?php echo e(route('create.product')); ?>" class="btn border add-btn shadow-none mx-2 d-none d-md-block"
                                      data-toggle="modal" data-target="#new-order"><i class="las la-plus mr-2"></i>New Product</a> -->
                              </li>
                              <li class="nav-item nav-icon search-content">
                                  <a href="#" class="search-toggle rounded" id="dropdownSearch" data-toggle="dropdown"
                                      aria-haspopup="true" aria-expanded="false">
                                      <i class="ri-search-line"></i>
                                  </a>
                                  <div class="iq-search-bar iq-sub-dropdown dropdown-menu" aria-labelledby="dropdownSearch">
                                      <form action="#" class="searchbox p-2">
                                          <div class="form-group mb-0 position-relative">
                                              <input type="text" class="text search-input font-size-12"
                                                  placeholder="type here to search...">
                                              <a href="#" class="search-link"><i class="las la-search"></i></a>
                                          </div>
                                      </form>
                                  </div>
                              </li>
                              <li class="nav-item nav-icon dropdown">
                                  <a href="#" class="search-toggle dropdown-toggle" id="dropdownMenuButton2"
                                      data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
                                          fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                          stroke-linejoin="round" class="feather feather-mail">
                                          <path
                                              d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z">
                                          </path>
                                          <polyline points="22,6 12,13 2,6"></polyline>
                                      </svg>
                                      <span class="bg-primary"></span>
                                  </a>
                                  <div class="iq-sub-dropdown dropdown-menu" aria-labelledby="dropdownMenuButton2">
                                      <div class="card shadow-none m-0">
                                          <div class="card-body p-0 ">
                                              <div class="cust-title p-3">
                                                  <div class="d-flex align-items-center justify-content-between">
                                                      <h5 class="mb-0">All Messages</h5>
                                                      <a class="badge badge-primary badge-card" href="#">3</a>
                                                  </div>
                                              </div>
                                              <div class="px-3 pt-0 pb-0 sub-card">
                                                  <a href="#" class="iq-sub-card">
                                                      <div class="media align-items-center cust-card py-3 border-bottom">
                                                          <div class="">
                                                              <img class="avatar-50 rounded-small"
                                                                  src="<?php echo e(asset('assets/images/user/01.jpg')); ?>" alt="01">
                                                          </div>
                                                          <div class="media-body ml-3">
                                                              <div class="d-flex align-items-center justify-content-between">
                                                                  <h6 class="mb-0">Emma Watson</h6>
                                                                  <small class="text-dark"><b>12 : 47 pm</b></small>
                                                              </div>
                                                              <small class="mb-0">Lorem ipsum dolor sit amet</small>
                                                          </div>
                                                      </div>
                                                  </a>
                                                  <a href="#" class="iq-sub-card">
                                                      <div class="media align-items-center cust-card py-3 border-bottom">
                                                          <div class="">
                                                              <img class="avatar-50 rounded-small"
                                                                  src="<?php echo e(asset('assets/images/user/02.jpg')); ?>" alt="02">
                                                          </div>
                                                          <div class="media-body ml-3">
                                                              <div class="d-flex align-items-center justify-content-between">
                                                                  <h6 class="mb-0">Ashlynn Franci</h6>
                                                                  <small class="text-dark"><b>11 : 30 pm</b></small>
                                                              </div>
                                                              <small class="mb-0">Lorem ipsum dolor sit amet</small>
                                                          </div>
                                                      </div>
                                                  </a>
                                                  <a href="#" class="iq-sub-card">
                                                      <div class="media align-items-center cust-card py-3">
                                                          <div class="">
                                                              <img class="avatar-50 rounded-small"
                                                                  src="<?php echo e(asset('assets/images/user/03.jpg')); ?>" alt="03">
                                                          </div>
                                                          <div class="media-body ml-3">
                                                              <div class="d-flex align-items-center justify-content-between">
                                                                  <h6 class="mb-0">Kianna Carder</h6>
                                                                  <small class="text-dark"><b>11 : 21 pm</b></small>
                                                              </div>
                                                              <small class="mb-0">Lorem ipsum dolor sit amet</small>
                                                          </div>
                                                      </div>
                                                  </a>
                                              </div>
                                              <a class="right-ic btn btn-primary btn-block position-relative p-2" href="#"
                                                  role="button">
                                                  View All
                                              </a>
                                          </div>
                                      </div>
                                  </div>
                              </li>
                              <li class="nav-item nav-icon dropdown">
                                  <a href="#" class="search-toggle dropdown-toggle" id="dropdownMenuButton"
                                      data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
                                          fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                          stroke-linejoin="round" class="feather feather-bell">
                                          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                                          <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                                      </svg>
                                      <span class="bg-primary "></span>
                                  </a>
                                  <div class="iq-sub-dropdown dropdown-menu" aria-labelledby="dropdownMenuButton">
                                      <div class="card shadow-none m-0">
                                          <div class="card-body p-0 ">
                                              <div class="cust-title p-3">
                                                  <div class="d-flex align-items-center justify-content-between">
                                                      <h5 class="mb-0">Notifications</h5>
                                                      <a class="badge badge-primary badge-card" href="#">3</a>
                                                  </div>
                                              </div>
                                              <div class="px-3 pt-0 pb-0 sub-card">
                                                  <a href="#" class="iq-sub-card">
                                                      <div class="media align-items-center cust-card py-3 border-bottom">
                                                          <div class="">
                                                              <img class="avatar-50 rounded-small"
                                                                  src="<?php echo e(asset('assets/images/user/01.jpg')); ?>" alt="01">
                                                          </div>
                                                          <div class="media-body ml-3">
                                                              <div class="d-flex align-items-center justify-content-between">
                                                                  <h6 class="mb-0">Emma Watson</h6>
                                                                  <small class="text-dark"><b>12 : 47 pm</b></small>
                                                              </div>
                                                              <small class="mb-0">Lorem ipsum dolor sit amet</small>
                                                          </div>
                                                      </div>
                                                  </a>
                                                  <a href="#" class="iq-sub-card">
                                                      <div class="media align-items-center cust-card py-3 border-bottom">
                                                          <div class="">
                                                              <img class="avatar-50 rounded-small"
                                                                  src="<?php echo e(asset('assets/images/user/02.jpg')); ?>" alt="02">
                                                          </div>
                                                          <div class="media-body ml-3">
                                                              <div class="d-flex align-items-center justify-content-between">
                                                                  <h6 class="mb-0">Ashlynn Franci</h6>
                                                                  <small class="text-dark"><b>11 : 30 pm</b></small>
                                                              </div>
                                                              <small class="mb-0">Lorem ipsum dolor sit amet</small>
                                                          </div>
                                                      </div>
                                                  </a>
                                                  <a href="#" class="iq-sub-card">
                                                      <div class="media align-items-center cust-card py-3">
                                                          <div class="">
                                                              <img class="avatar-50 rounded-small"
                                                                  src="<?php echo e(asset('assets/images/user/03.jpg')); ?>" alt="03">
                                                          </div>
                                                          <div class="media-body ml-3">
                                                              <div class="d-flex align-items-center justify-content-between">
                                                                  <h6 class="mb-0">Kianna Carder</h6>
                                                                  <small class="text-dark"><b>11 : 21 pm</b></small>
                                                              </div>
                                                              <small class="mb-0">Lorem ipsum dolor sit amet</small>
                                                          </div>
                                                      </div>
                                                  </a>
                                              </div>
                                              <a class="right-ic btn btn-primary btn-block position-relative p-2" href="#"
                                                  role="button">
                                                  View All
                                              </a>
                                          </div>
                                      </div>
                                  </div>
                              </li>
                              <li class="nav-item nav-icon dropdown caption-content">
                                  <a href="#" class="search-toggle dropdown-toggle" id="dropdownMenuButton4"
                                      data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      <img src="<?php echo e(asset('assets/images/user/1.png')); ?>" class="img-fluid rounded" alt="user">
                                  </a>
                                  <div class="iq-sub-dropdown dropdown-menu" aria-labelledby="dropdownMenuButton">
                                      <div class="card shadow-none m-0">
                                          <div class="card-body p-0 text-center">
                                              <div class="media-body profile-detail text-center">
                                                  <img src="<?php echo e(asset('assets/images/page-img/profile-bg.jpg')); ?>" alt="profile-bg"
                                                      class="rounded-top img-fluid mb-4">
                                                  <img src="<?php echo e(asset('assets/images/user/1.png')); ?>" alt="profile-img"
                                                      class="rounded profile-img img-fluid avatar-70">
                                              </div>
                                              <div class="p-3">
                                                  <h5 class="mb-1"></h5>
                                                  <p class="mb-0"><?php echo e(ucfirst(config('multiauth.prefix'))); ?></p>
                                                  <div class="d-flex align-items-center justify-content-center mt-3">
                                                      <a href="#" class="btn border mr-2">Profile</a>
                                                          <?php if(auth()->guard()->guest()): ?>
                                                            <?php if(Route::has('login')): ?>
                                                                
                                                                    <a class="btn border" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                                                
                                                            <?php endif; ?>

                                                            <?php if(Route::has('register')): ?>
                                                                    <a class="btn border" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            
                                                                    <?php echo e(Auth::user()->name); ?>

                                                                </a>
                                                                    <a class="btn border" href="/admin/logout"onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                                                        <?php echo e(__('Logout')); ?>

                                                                    </a>
                                                      <!-- <a href="#" class="btn border">Sign Out</a> -->

                                    <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                
                        <?php endif; ?>
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </li>
                          </ul>
                      </div>
                  </div>
              </nav>
          </div>
      </div><?php /**PATH D:\xampp\htdocs\report\vendor\bitfumes\laravel-multiauth\src/views/partials/header.blade.php ENDPATH**/ ?>