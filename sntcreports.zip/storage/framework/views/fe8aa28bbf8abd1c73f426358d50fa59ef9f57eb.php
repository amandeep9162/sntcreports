<footer class="iq-footer">
            <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item"><a href="privacy-policy.html">Privacy Policy</a></li>
                                <li class="list-inline-item"><a href="terms-of-service.html">Terms of Use</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-6 text-right">
                            <span class="mr-1"><script>document.write(new Date().getFullYear())</script>©</span> <a href="#" class="">Employee Management</a>.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Backend Bundle JavaScript -->
    <script src="<?php echo e(asset('assets/js/backend-bundle.min.js')); ?>"></script>
    
    <!-- Table Treeview JavaScript -->
    <script src="<?php echo e(asset('assets/js/table-treeview.js')); ?>"></script>
    
    <!-- Chart Custom JavaScript -->
    <script src="<?php echo e(asset('assets/js/customizer.js')); ?>"></script>
    
    <!-- Chart Custom JavaScript -->
    <script async src="<?php echo e(asset('assets/js/chart-custom.js')); ?>"></script>
    
    <!-- app JavaScript -->
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
    <script >
  $(document).ready(function(){
    $('table.tableID').DataTable({
        paging: true,
        "order": [[ 1, "asc" ]],
        dom: 'Bfrtip',
       buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5'
        ]
    });
});
</script>
  </body>


</html><?php /**PATH D:\xampp\htdocs\report\vendor\bitfumes\laravel-multiauth\src/views/partials/footer.blade.php ENDPATH**/ ?>