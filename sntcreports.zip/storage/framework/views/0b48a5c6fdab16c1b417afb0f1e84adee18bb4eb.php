
<?php $__env->startSection('content'); ?>
<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #80828b;
  color: white;
}
#ApendUsersTask tr td{
    text-transform: capitalize;
}
.hide{
    display: none;
}
.tasks .dataTables_filter, .dataTables_info,.dataTables_empty { display: none; }
.tasks .dt-buttons{ margin-bottom: 15px; }
</style>
     <div class="content-page">
     <div class="container-fluid ">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header ">
                        <div class="header-title">
                            <h4 class="card-title">Report</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('admin.getReport')); ?>" method="POST" data-toggle="validator">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                                              
                                <div class="col-md-12">
                                <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Date</label>
                                        <input type="Date" class="form-control" placeholder="" data-errors="" name="date" value="" >
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                </div>
                                </div>
                                <div class="col-md-12">
                                <div class="row">
                                <!-- <div class="col-md-6">
                                    <div class="form-group">
                                        <label>In Time</label>
                                        <input type="time" class="form-control" placeholder="" data-errors="" name="inTime" value="" >
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Out Time</label>
                                        <input type="time" class="form-control" placeholder="" data-errors="" name="outTime" value="" >
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div> -->
                                <div class="col-md-12">
                                        <input type="radio" name="name[]" value="all">
                                        <label>All</label> 
                                        <label>Users</label> 
                                </div>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key != 0): ?>
                                <div class="col-md-4">
                                    <div class="form-group">
                                                <input type="checkbox" name="name[]" value="<?php echo e($user['id']); ?>">
                                        <label><?php echo e($user['name']); ?></label> 
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                </div>
                              
                               <div class="col-md-12">
                                   
                                <hr>
                               </div>
                            </div>                            
                            <button type="submit" class="btn btn-primary mr-2">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
            <div class="row">
                <div class="col-sm-12">
                <div class="">
                       
                    <table data-order='[[ 0, "desc" ]]' class="align-middle text-truncate mb-0 table table-borderless cell-border table-hover tableID"  id="customers">
                        <thead> 
                      <tr>
                        <th><input type="checkbox" name="checkbox" value="all" class="getTask" id="checkAll"> All</th>
                        <th>User</th>
                        <!-- <th>Tasks</th> -->
                        <th>Date</th>
                        <th>In Time</th>
                        <th>Out Time</th>
                        <th>Tasks</th>
                      </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $dailyReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dailyReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $reports = json_decode($dailyReport['report']);
                    ?>
                      <tr>
                        <td><input type="checkbox" name="checkbox" id="<?php echo e($key); ?>" value="<?php echo e($dailyReport['id']); ?>" class="getTask"></td>
                        <td><?php if($dailyReport->user): ?><?php echo e($dailyReport->user['name']); ?><?php endif; ?></td>
                        <td><?php echo e(Carbon\Carbon::parse($dailyReport['date'])->format('d/M/Y')); ?> 
                        </td>
                        <td><?php echo e(Carbon\Carbon::parse($dailyReport['in_time'])->format('h:i:a')); ?></td>
                        <td><?php echo e(Carbon\Carbon::parse($dailyReport['out_time'])->format('h:i:a')); ?></td>
                        <td >
                        <ul>
                        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($report); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                    </table>
                </div>
                </div>
                <div class="col-md-4 tasks" >
                <div class="hide" id="usersTasks">
                       
                    <table data-order='[[ 0, "desc" ]]' class="align-middle text-truncate mb-0 table table-borderless cell-border table-hover tableID" id="customers">
                      <thead>
                          
                      <tr>
                        
                        <th>Tasks</th>
                        
                      </tr>
                    
                      </thead>
                      <tbody id="ApendUsersTask">
                          
                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>
        
    </div>
      </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script >
$(document).on('click','.getTask',function() {
            $('#usersTasks').show();
            let isChecked = $(this)[0].checked
            var val = $(this).val();
            var id = $(this).attr('id');
            console.log(isChecked);
            console.log('id');
            console.log(id);
            if(isChecked == false){

            // $('#usersTasks').hide();
                $('.relDiv'+val+id).remove();
            }else{

            $.ajax({
                    url: "/admin/getreporttasks/"+val, 
                    type: "GET", 
                    success: function(result) {
                var reports = [];
                $.each(result.dailyReports, function(k, v) {
                    
                    reports = JSON.parse(v.report);
                    $.each(reports, function(ke, vall) {
                        $('#ApendUsersTask').append('<tr class="relDiv'+val+id+'"><td>'+vall+'</td> </tr>');
                        
                    });
                });
            }});
}
        });
</script>

 <script >
$("#checkAll").click(function(){
    $('input:checkbox').not(this).prop('checked', this.checked);
    $('.dataTables_filter').css('display','none');
});
</script>


    <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('multiauth::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\report\vendor\bitfumes\laravel-multiauth\src/views/report/list.blade.php ENDPATH**/ ?>