
<?php $__env->startSection('content'); ?>
     <div class="content-page">
     <div class="container-fluid ">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header ">
                        <div class="header-title">
                            <h4 class="card-title">Enter Daily Work Report</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('report.store')); ?>"  method="POST" data-toggle="validator"  >
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                                              
                                <div class="col-md-12">
                                <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Date</label>
                                        <input type="text" class="form-control" placeholder="" data-errors="" id="datePick"  value="" readonly>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>In Time</label>
                                        <input type="time" class="form-control" placeholder="" data-errors="" name="in_time" value="<?php if($dailyReports): ?><?php echo e($dailyReports['in_time']); ?><?php endif; ?>" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Out Time</label>
                                        <input type="time" class="form-control" placeholder="" data-errors="" name="out_time" value="<?php if($dailyReports): ?><?php echo e($dailyReports['out_time']); ?><?php endif; ?>" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                               <!--  <?php for($x = 0; $x <= 3; $x++): ?>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="" data-errors="" name="report[<?php echo e($x); ?>]" value="" >
                                    </div>
                                </div>
                                <?php endfor; ?> -->
                                <?php if($dailyReports): ?>
                                <?php $__currentLoopData = json_decode($dailyReports['report']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-12">
                                <div class="row ">
                                <div class="col-md-11">
                                    <div class="form-group">
                                        <input type="text" name="report[]" class="form-control" value="<?php echo e($task); ?>"/>
                                        
                                    </div>
                                </div>
                                
                            </div>
                            </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>
                              <div class="col-md-12">
                                <div class="row field_wrapper">
                                <div class="col-md-11">
                                    <div class="form-group">
                                        <input type="text" name="report[]" class="form-control" value=""/>
                                        
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <a href="javascript:void(0);" class="add_button" title="Add field"><i class="fa fa-plus"></i></a>
                                </div>
                            </div>
                            </div>   
                            </div>                            
                                        <input type="hidden" id="datePickH" name="date" value="" >
                            <button type="submit" name="save" class="btn btn-primary mr-2">Save</button>
                            <button  class="btn btn-primary mr-2 float-right" onclick="return confirm('Do you really want to submit the report?');" name="name" value="submit">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
      </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script >
    var i = 1;
$(document).ready(function(){
    var maxField = 30; //Input fields increment limitation
    var addButton = $('.add_button'); //Add button selector
    var wrapper = $('.field_wrapper'); //Input field wrapper
    var fieldHTML = '<div class="col-md-12 abc"><div class="row field_wrapper"> <div class="col-md-11"> <div class="form-group"> <input type="text" name="report[]" class="form-control" value=""/> </div> </div> <div class="col-md-1"><a href="javascript:void(0);" class="remove_button"><i class="fa fa-trash"></i></a> </div> </div></div></div>'; //New input field html
    var x = 1; //Initial field counter is 1

    //Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function(e){
        e.preventDefault();
        $(this).parents('.abc').remove(); //Remove field html
        x--; //Decrement field counter
    });
});
$(function(){ 
var dt = new Date();
    var time =  dt.getDate()+ "/" +(dt.getMonth()+1) + "/" +dt.getFullYear();
    
        $('#datePickH').val(time);
        $('#datePick').val(time);
 });               

</script>
<script>
function validate(form) {

    // validation code here ...


    if(!valid) {
        alert('Please correct the errors in the form!');
        return false;
    }
    else {
        return confirm('Do you really want to submit the form?');
    }
}
</script>
<form onsubmit="return validate(this);">
    <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('multiauth::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/sntcgroup/reports.sntcgroup.com/vendor/bitfumes/laravel-multiauth/src/views/report/add.blade.php ENDPATH**/ ?>