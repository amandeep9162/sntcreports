<?php
use App\Http\Controllers\QrCodeController;
use App\Http\Controllers\ProductController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('home');
Route::get('/generate-qrcode', [QrCodeController::class, 'index'])->name('create.product.barcode');
Route::get('/add-product', [ProductController::class, 'create'])->name('create.product');
Route::get('/list-product', [ProductController::class, 'index'])->name('list.product');
