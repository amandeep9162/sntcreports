<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\QrCodeController;
use App\Http\Controllers\ProductController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->middleware(['auth']);

Route::get('/dashboard', function () {
    return view('welcome');
    // return view('dashboard');
})->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';


Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/generate-qrcode', [QrCodeController::class, 'index'])->name('create.product.barcode');
Route::get('/qr-code/create', [QrCodeController::class, 'create'])->name('create.qr-code');
Route::get('/generate/link', [QrCodeController::class, 'genrate'])->name('genrate.qrcode');
Route::get('/verify/qrcode/{id}', [QrCodeController::class, 'verify'])->name('verify.qrcode');

Route::get('/add-product', [ProductController::class, 'create'])->name('create.product');
Route::get('/list-product', [ProductController::class, 'index'])->name('list.product');



// Admin 



